﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Desafio-CRUD.Models
{
    public class PessoaFisicaAcoes : IPessoaFisicaAcoes
    {
        private List<PessoaFisica> PessoaFisicas = new List<PessoaFisica>();
        private int _nextId = 1;

        public PessoaFisicaAcoes()
        {
            Add(new PessoaFisica { Id = 1, Nome = "Ricardo", DataNascimento = Convert.ToDateTime("23/06/1952"), ValorRenda = 7500.99, CPF = "000.000.235-62" });;
            Add(new PessoaFisica { Id = 2, Nome = "Vinicius", DataNascimento = Convert.ToDateTime("21/04/1998"), ValorRenda = 8600.16, CPF = "000.000.321-94" });
            Add(new PessoaFisica { Id = 3, Nome = "Bruno", DataNascimento = Convert.ToDateTime("16/04/1996"), ValorRenda = 4500.16, CPF = "000.000.456-96" });
            Add(new PessoaFisica { Id = 4, Nome = "Ana", DataNascimento = Convert.ToDateTime("26/06/1999"), ValorRenda = 3200.25, CPF = "000.000.442-98" });
        }

        public bool Add(PessoaFisica item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.Id = _nextId++;
            PessoaFisicas.Add(item);

            return true;
        }

        public PessoaFisica Get(int id)
        {
            return PessoaFisicas.Find(p => p.Id == id);
        }

        public IEnumerable<PessoaFisica> GetAll()
        {
            return PessoaFisicas;
        }

        public void Remove(int id)
        {
            PessoaFisicas.RemoveAll(p => p.Id == id);
        }

        public bool Update(PessoaFisica item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            int index = PessoaFisicas.FindIndex(p => p.Id == item.Id);

            if (index == -1)
            {
                return false;
            }
            PessoaFisicas.RemoveAt(index);
            PessoaFisicas.Add(item);
            return true;
        }
    }
}