﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Desafio-CRUD.DAL
{
    public class AcessoDados
    {
        MySqlConnection conexao = null;

        //string strConexao = @"Server=localhost;Database=cadastropessoafisica;Uid=root;Pwd='123456';Connect Timeout=30;";
    }
}